MAX SEKAI SKILLS 1.0.0 — PROTOTIPO

Objetivo:
- Minecraft Java 1.20.2
- Minecraft Forge 48.1.0
- Java 17

IMPORTANTE:
Este paquete contiene el PROYECTO FUENTE, no un .jar ya compilado. El codigo incluye los 11 arboles de dones y usa Map.ofEntries para registrar todos ellos.
El entorno de creación no pudo descargar ForgeGradle/dependencias porque no tiene conexión al repositorio de Forge, así que no sería correcto entregarte un .jar falso o que no funcione.

COMANDOS:
- /maxsekai ayuda
- /maxsekai asignar <jugador> <don>
- /maxsekai puntos <jugador> <cantidad>
- /maxsekai mejorar
- /maxsekai estado

Dones disponibles:
invocador, mago, sanador, espadachin, elfo, bestia, draconido, enano, espiritu, vampiro, sirenido

PERMISOS:
- Asignar dones y entregar puntos requiere permiso de operador nivel 2.
- Cada jugador puede usar /maxsekai mejorar para gastar 1 punto en su siguiente mejora.
- El jugador comienza en nivel 1 de la primera habilidad.
- Al alcanzar nivel 5, se desbloquea la siguiente habilidad en nivel 1.
- Cada árbol tiene seis habilidades.

COMPILAR:
1. Instalar Java 17.
2. En Windows, abrir una terminal en la carpeta del proyecto.
3. Ejecutar: gradle build (con conexion a internet para descargar ForgeGradle y las dependencias).
4. El archivo resultante estará en build/libs/maxsekai-skills-1.0.0.jar

NOTA DE PROTOTIPO:
Esta primera versión administra la asignación y progresión mediante comandos. Todavía no incluye menú gráfico, efectos reales de combate, ni selección visual de raza. Esas funciones se agregarán después de validar la progresión.
