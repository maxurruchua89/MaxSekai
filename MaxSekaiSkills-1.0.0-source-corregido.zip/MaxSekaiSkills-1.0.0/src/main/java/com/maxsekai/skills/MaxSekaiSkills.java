package com.maxsekai.skills;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.Map;

@Mod(MaxSekaiSkills.MODID)
public class MaxSekaiSkills {
    public static final String MODID = "maxsekai_skills";
    private static final String ROOT = "MaxSekaiSkills";

    // Six-step trees for the first prototype. The moderator assigns one of these paths.
    private static final Map<String, List<String>> TREES = Map.ofEntries(
        Map.entry("invocador", List.of("Llamado menor", "Lobo espiritual", "Guardianes gemelos", "Bestia arcana", "Ejercito espiritual", "Rey de las invocaciones")),
        Map.entry("mago", List.of("Chispa elemental", "Afinidad elemental", "Oleada elemental", "Armadura elemental", "Tormenta elemental", "Cataclismo elemental")),
        Map.entry("sanador", List.of("Toque curativo", "Luz restauradora", "Barrera sagrada", "Purificacion", "Zona de sanacion", "Milagro de vida")),
        Map.entry("espadachin", List.of("Corte veloz", "Paso relampago", "Doble filo", "Danza de espadas", "Instinto del espadachin", "Corte del vacio")),
        Map.entry("elfo", List.of("Vision elfica", "Raices atrapadoras", "Bendicion natural", "Espinas del bosque", "Espiritu del bosque", "Guardian ancestral")),
        Map.entry("bestia", List.of("Instinto salvaje", "Garras bestiales", "Fuerza animal", "Transformacion parcial", "Transformacion completa", "Bestia ancestral")),
        Map.entry("draconido", List.of("Escamas resistentes", "Llama draconica", "Resistencia al calor", "Aliento de dragon", "Armadura draconica", "Despertar del dragon")),
        Map.entry("enano", List.of("Cuerpo resistente", "Golpe de forja", "Sentido minero", "Armadura reforzada", "Maestro artesano", "Forja ancestral")),
        Map.entry("espiritu", List.of("Cuerpo etereo", "Proyectil espiritual", "Afinidad espiritual", "Barrera de energia", "Conexion espiritual", "Espiritu primordial")),
        Map.entry("vampiro", List.of("Sentidos nocturnos", "Velocidad vampirica", "Regeneracion", "Lanzas carmesi", "Forma de murcielago", "Senor de la noche")),
        Map.entry("sirenido", List.of("Adaptacion acuatica", "Chorro de agua", "Corriente marina", "Prision acuatica", "Marea protectora", "Senor de las mareas"))
    );

    public MaxSekaiSkills() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("maxsekai")
            .then(Commands.literal("ayuda")
                .executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "MaxSekai: /maxsekai asignar <jugador> <don> | /maxsekai puntos <jugador> <cantidad> | /maxsekai mejorar | /maxsekai estado"
                    ), false);
                    return 1;
                }))
            .then(Commands.literal("asignar")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("jugador", EntityArgument.player())
                    .then(Commands.argument("don", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            TREES.keySet().forEach(builder::suggest);
                            return builder.buildFuture();
                        })
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "jugador");
                            String key = StringArgumentType.getString(ctx, "don").toLowerCase();
                            List<String> tree = TREES.get(key);
                            if (tree == null) {
                                ctx.getSource().sendFailure(Component.literal("Don desconocido. Usa /maxsekai ayuda."));
                                return 0;
                            }
                            CompoundTag data = target.getPersistentData().getCompound(ROOT);
                            data.putString("don", key);
                            data.putInt("skillIndex", 0);
                            data.putInt("skillLevel", 1);
                            data.putInt("points", 0);
                            target.getPersistentData().put(ROOT, data);
                            target.sendSystemMessage(Component.literal("Tu don de reencarnacion ha sido asignado: " + key + ". Tu primera habilidad es " + tree.get(0) + " (nivel 1)."));
                            ctx.getSource().sendSuccess(() -> Component.literal("Don " + key + " asignado a " + target.getGameProfile().getName() + "."), true);
                            return 1;
                        }))))
            .then(Commands.literal("puntos")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("jugador", EntityArgument.player())
                    .then(Commands.argument("cantidad", IntegerArgumentType.integer(1, 10000))
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "jugador");
                            int amount = IntegerArgumentType.getInteger(ctx, "cantidad");
                            CompoundTag data = getData(target);
                            data.putInt("points", data.getInt("points") + amount);
                            target.getPersistentData().put(ROOT, data);
                            ctx.getSource().sendSuccess(() -> Component.literal("Se agregaron " + amount + " puntos a " + target.getGameProfile().getName() + "."), true);
                            return 1;
                        }))))
            .then(Commands.literal("mejorar")
                .executes(ctx -> upgrade(ctx.getSource().getPlayerOrException())))
            .then(Commands.literal("estado")
                .executes(ctx -> showStatus(ctx.getSource().getPlayerOrException())))
        );
    }

    private static CompoundTag getData(ServerPlayer player) {
        return player.getPersistentData().getCompound(ROOT).copy();
    }

    private static int upgrade(ServerPlayer player) {
        CompoundTag data = getData(player);
        String key = data.getString("don");
        List<String> tree = TREES.get(key);
        if (tree == null || tree.isEmpty()) {
            player.sendSystemMessage(Component.literal("Todavia no tienes un don asignado. Pidele al moderador que use /maxsekai asignar."));
            return 0;
        }
        int points = data.getInt("points");
        int index = data.getInt("skillIndex");
        int level = data.getInt("skillLevel");
        if (points < 1) {
            player.sendSystemMessage(Component.literal("No tienes puntos de habilidad. Pidele puntos al moderador."));
            return 0;
        }
        if (index >= tree.size()) return 0;
        if (level >= 5) {
            player.sendSystemMessage(Component.literal("Esta habilidad ya esta al nivel maximo."));
            return 0;
        }
        data.putInt("points", points - 1);
        level++;
        data.putInt("skillLevel", level);
        String message = "Habilidad " + tree.get(index) + " ahora nivel " + level + ".";
        if (level == 5 && index < tree.size() - 1) {
            index++;
            data.putInt("skillIndex", index);
            data.putInt("skillLevel", 1);
            message += " Se desbloqueo: " + tree.get(index) + " (nivel 1).";
        } else if (level == 5 && index == tree.size() - 1) {
            message += " ¡Alcanzaste la habilidad definitiva!";
        }
        player.getPersistentData().put(ROOT, data);
        player.sendSystemMessage(Component.literal(message));
        return 1;
    }

    private static int showStatus(ServerPlayer player) {
        CompoundTag data = getData(player);
        String key = data.getString("don");
        List<String> tree = TREES.get(key);
        if (tree == null) {
            player.sendSystemMessage(Component.literal("No tienes un don asignado."));
            return 1;
        }
        int index = data.getInt("skillIndex");
        int level = data.getInt("skillLevel");
        player.sendSystemMessage(Component.literal("Don: " + key + " | Habilidad: " + tree.get(index) + " | Nivel: " + level + "/5 | Puntos: " + data.getInt("points")));
        if (index + 1 < tree.size()) {
            player.sendSystemMessage(Component.literal("Siguiente habilidad: " + tree.get(index + 1) + " (se desbloquea al llegar al nivel 5)."));
        } else {
            player.sendSystemMessage(Component.literal("Estas en la ultima habilidad de tu arbol."));
        }
        return 1;
    }
}
