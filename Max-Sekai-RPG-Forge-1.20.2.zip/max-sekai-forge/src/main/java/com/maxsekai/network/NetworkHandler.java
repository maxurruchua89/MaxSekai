package com.maxsekai.network;

import com.maxsekai.MaxSekaiMod;
import com.maxsekai.data.PlayerRpgData;
import com.maxsekai.skill.AbilityEngine;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.network.Channel;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.SimpleChannel;

public final class NetworkHandler {
    private static final int PROTOCOL = 1;
    public static final SimpleChannel CHANNEL = ChannelBuilder.named(
                    new ResourceLocation(MaxSekaiMod.MOD_ID, "main"))
            .networkProtocolVersion(PROTOCOL)
            .clientAcceptedVersions(Channel.VersionTest.exact(PROTOCOL))
            .serverAcceptedVersions(Channel.VersionTest.exact(PROTOCOL))
            .simpleChannel();
    private static boolean registered;

    private NetworkHandler() {}

    public static void register() {
        if (registered) {
            return;
        }
        registered = true;
        CHANNEL.messageBuilder(UpgradePacket.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder(UpgradePacket::encode).decoder(UpgradePacket::decode).consumerMainThread(UpgradePacket::handle).add();
        CHANNEL.messageBuilder(EquipPacket.class, 1, NetworkDirection.PLAY_TO_SERVER)
                .encoder(EquipPacket::encode).decoder(EquipPacket::decode).consumerMainThread(EquipPacket::handle).add();
        CHANNEL.messageBuilder(SelectSlotPacket.class, 2, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SelectSlotPacket::encode).decoder(SelectSlotPacket::decode).consumerMainThread(SelectSlotPacket::handle).add();
        CHANNEL.messageBuilder(CastPacket.class, 3, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CastPacket::encode).decoder(CastPacket::decode).consumerMainThread(CastPacket::handle).add();
        CHANNEL.messageBuilder(ClaimMissionPacket.class, 4, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ClaimMissionPacket::encode).decoder(ClaimMissionPacket::decode).consumerMainThread(ClaimMissionPacket::handle).add();
        CHANNEL.messageBuilder(SyncPacket.class, 5, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncPacket::encode).decoder(SyncPacket::decode).consumerMainThread(SyncPacket::handle).add();
    }

    public static void sync(ServerPlayer player) {
        player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
            CompoundTag snapshot = data.serializeNBT();
            CompoundTag remaining = new CompoundTag();
            long now = player.getServer().overworld().getGameTime();
            for (com.maxsekai.skill.SkillTree tree : com.maxsekai.skill.SkillTree.values()) {
                for (com.maxsekai.skill.SkillDefinition skill : tree.skills()) {
                    remaining.putInt(skill.id(), (int) Math.max(0,
                            Math.min(Integer.MAX_VALUE, data.getCooldownUntil(skill.id()) - now)));
                }
            }
            snapshot.put("cooldowns_remaining", remaining);
            CHANNEL.send(new SyncPacket(snapshot), PacketDistributor.PLAYER.with(player));
        });
    }

    public record UpgradePacket(String skillId) {
        private static void encode(UpgradePacket packet, FriendlyByteBuf buffer) {
            buffer.writeUtf(packet.skillId(), 80);
        }

        private static UpgradePacket decode(FriendlyByteBuf buffer) {
            return new UpgradePacket(buffer.readUtf(80));
        }

        private static void handle(UpgradePacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player != null) {
                player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
                    if (data.upgradeSkill(packet.skillId())) {
                        player.displayClientMessage(net.minecraft.network.chat.Component.literal("Habilidad mejorada."), true);
                    } else {
                        player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                                "No puedes mejorar esa habilidad: revisa tu árbol, puntos y nivel máximo."), true);
                    }
                    sync(player);
                });
            }
        }
    }

    public record EquipPacket(int slot, String skillId) {
        private static void encode(EquipPacket packet, FriendlyByteBuf buffer) {
            buffer.writeVarInt(packet.slot());
            buffer.writeUtf(packet.skillId(), 80);
        }

        private static EquipPacket decode(FriendlyByteBuf buffer) {
            int slot = buffer.readVarInt();
            String skillId = buffer.readUtf(80);
            return new EquipPacket(slot, skillId);
        }

        private static void handle(EquipPacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player == null || packet.slot() < 0 || packet.slot() >= 4) {
                return;
            }
            player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
                if (data.setEquipment(packet.slot(), packet.skillId())) {
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                            packet.skillId().isBlank() ? "Espacio vaciado." : "Habilidad equipada."), true);
                } else {
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                            "Solo puedes equipar habilidades aprendidas de tu árbol."), true);
                }
                sync(player);
            });
        }
    }

    public record SelectSlotPacket(int slot) {
        private static void encode(SelectSlotPacket packet, FriendlyByteBuf buffer) {
            buffer.writeVarInt(packet.slot());
        }

        private static SelectSlotPacket decode(FriendlyByteBuf buffer) {
            return new SelectSlotPacket(buffer.readVarInt());
        }

        private static void handle(SelectSlotPacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player == null || packet.slot() < 0 || packet.slot() >= 4) {
                return;
            }
            player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
                data.setSelectedSlot(packet.slot());
                sync(player);
            });
        }
    }

    public record CastPacket() {
        private static void encode(CastPacket packet, FriendlyByteBuf buffer) {}
        private static CastPacket decode(FriendlyByteBuf buffer) { return new CastPacket(); }

        private static void handle(CastPacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player != null) {
                AbilityEngine.tryCast(player);
            }
        }
    }

    public record ClaimMissionPacket(int mission) {
        private static void encode(ClaimMissionPacket packet, FriendlyByteBuf buffer) {
            buffer.writeVarInt(packet.mission());
        }

        private static ClaimMissionPacket decode(FriendlyByteBuf buffer) {
            return new ClaimMissionPacket(buffer.readVarInt());
        }

        private static void handle(ClaimMissionPacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player != null && packet.mission() >= 0 && packet.mission() < 3) {
                AbilityEngine.claimMission(player, packet.mission());
            }
        }
    }

    public record SyncPacket(CompoundTag data) {
        private static void encode(SyncPacket packet, FriendlyByteBuf buffer) {
            buffer.writeNbt(packet.data());
        }

        private static SyncPacket decode(FriendlyByteBuf buffer) {
            CompoundTag tag = buffer.readNbt();
            return new SyncPacket(tag == null ? new CompoundTag() : tag);
        }

        private static void handle(SyncPacket packet, CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            context.enqueueWork(() -> net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(
                    net.minecraftforge.api.distmarker.Dist.CLIENT,
                    () -> () -> com.maxsekai.client.ClientRpgState.update(packet.data())));
        }
    }
}
