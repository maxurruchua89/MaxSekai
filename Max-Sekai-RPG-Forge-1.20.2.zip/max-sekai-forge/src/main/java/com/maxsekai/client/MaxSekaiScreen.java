package com.maxsekai.client;

import com.maxsekai.network.NetworkHandler;
import com.maxsekai.skill.AbilityEngine;
import com.maxsekai.skill.SkillDefinition;
import com.maxsekai.skill.SkillTree;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class MaxSekaiScreen extends Screen {
    private enum Tab { SKILLS, EQUIPMENT, MISSIONS }

    private Tab activeTab = Tab.SKILLS;
    private int focusedSkill;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    public MaxSekaiScreen() {
        super(Component.literal("Max Sekai"));
    }

    @Override
    protected void init() {
        panelWidth = Math.min(760, width - 24);
        panelHeight = Math.min(420, height - 24);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearWidgets();
        int tabY = panelY + 48;
        int tabWidth = Math.max(92, (panelWidth - 50) / 3);
        addRenderableWidget(Button.builder(Component.literal("HABILIDADES"),
                button -> changeTab(Tab.SKILLS)).bounds(panelX + 16, tabY, tabWidth, 22).build());
        addRenderableWidget(Button.builder(Component.literal("EQUIPAMIENTO"),
                button -> changeTab(Tab.EQUIPMENT)).bounds(panelX + 25 + tabWidth, tabY, tabWidth, 22).build());
        addRenderableWidget(Button.builder(Component.literal("MISIONES"),
                button -> changeTab(Tab.MISSIONS)).bounds(panelX + 34 + tabWidth * 2, tabY, tabWidth, 22).build());

        SkillTree tree = ClientRpgState.tree();
        if (activeTab == Tab.SKILLS && tree != null) {
            int rowY = panelY + 94;
            int leftWidth = (panelWidth - 45) * 2 / 3;
            for (int i = 0; i < tree.skills().size(); i++) {
                int index = i;
                SkillDefinition skill = tree.skills().get(i);
                int rowTop = rowY + i * 38;
                addRenderableWidget(Button.builder(Component.literal(skill.name() + "  ·  Niv. " +
                                ClientRpgState.skillLevel(skill.id())),
                        button -> focusedSkill = index).bounds(panelX + 16, rowTop, leftWidth - 4, 26).build());
            }
            int rightX = panelX + 28 + leftWidth;
            int rightWidth = panelWidth - (rightX - panelX) - 16;
            addRenderableWidget(Button.builder(Component.literal("Mejorar"),
                    button -> {
                        SkillDefinition skill = tree.skills().get(Math.max(0, Math.min(focusedSkill, 5)));
                        NetworkHandler.CHANNEL.send(new NetworkHandler.UpgradePacket(skill.id()),
                                net.minecraftforge.network.PacketDistributor.SERVER.noArg());
                    }).bounds(rightX, panelY + 330, rightWidth, 24).build());
        }

        if (activeTab == Tab.EQUIPMENT && tree != null) {
            int rowY = panelY + 236;
            int leftWidth = (panelWidth - 45) * 2 / 3;
            for (int slot = 0; slot < 4; slot++) {
                int index = slot;
                String skillId = ClientRpgState.equipment(slot);
                SkillDefinition equipped = SkillDefinition.find(skillId);
                String slotName = "Espacio " + (slot + 1) + (equipped == null ? " · vacío" : " · " + equipped.name());
                addRenderableWidget(Button.builder(Component.literal(slotName),
                        button -> NetworkHandler.CHANNEL.send(new NetworkHandler.SelectSlotPacket(index),
                                net.minecraftforge.network.PacketDistributor.SERVER.noArg()))
                        .bounds(panelX + 16 + (slot % 2) * (leftWidth / 2), panelY + 95 + (slot / 2) * 34,
                                leftWidth / 2 - 5, 24).build());
            }
            for (int i = 0; i < tree.skills().size(); i++) {
                SkillDefinition skill = tree.skills().get(i);
                if (ClientRpgState.skillLevel(skill.id()) <= 0) {
                    continue;
                }
                int rowTop = rowY + i * 27;
                int selectedSlot = ClientRpgState.selectedSlot();
                addRenderableWidget(Button.builder(Component.literal("Equipar " + skill.name()),
                        button -> NetworkHandler.CHANNEL.send(new NetworkHandler.EquipPacket(selectedSlot, skill.id()),
                                net.minecraftforge.network.PacketDistributor.SERVER.noArg()))
                        .bounds(panelX + 16, rowTop, leftWidth - 4, 24).build());
            }
            int rightX = panelX + 28 + leftWidth;
            int rightWidth = panelWidth - (rightX - panelX) - 16;
            addRenderableWidget(Button.builder(Component.literal("Quitar del espacio"),
                    button -> NetworkHandler.CHANNEL.send(new NetworkHandler.EquipPacket(
                                    ClientRpgState.selectedSlot(), ""),
                            net.minecraftforge.network.PacketDistributor.SERVER.noArg()))
                    .bounds(rightX, panelY + 330, rightWidth, 24).build());
        }

        if (activeTab == Tab.MISSIONS) {
            int rowY = panelY + 132;
            AbilityEngine.Mission[] missions = AbilityEngine.missions();
            for (int i = 0; i < missions.length; i++) {
                int index = i;
                AbilityEngine.Mission mission = missions[i];
                addRenderableWidget(Button.builder(Component.literal("Reclamar recompensa"),
                                button -> NetworkHandler.CHANNEL.send(new NetworkHandler.ClaimMissionPacket(index),
                                        net.minecraftforge.network.PacketDistributor.SERVER.noArg()))
                        .bounds(panelX + panelWidth - 204, rowY + i * 78, 184, 24).build());
            }
        }
    }

    private void changeTab(Tab tab) {
        activeTab = tab;
        rebuildButtons();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.fill(0, 0, width, height, 0xA6000000);
        graphics.fill(panelX - 1, panelY - 1, panelX + panelWidth + 1, panelY + panelHeight + 1, 0xFFB99B5B);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xF0111722);
        graphics.fill(panelX + 1, panelY + 1, panelX + panelWidth - 1, panelY + 42, 0xFF202C3C);

        graphics.drawString(font, Component.literal("MAX SEKAI  /  RPG"), panelX + 16, panelY + 12, 0xFFFFD989, false);
        SkillTree tree = ClientRpgState.tree();
        String treeTitle = tree == null ? "Sin don asignado" : tree.title();
        String summary = treeTitle + "   ·   Nivel " + ClientRpgState.level() +
                "   ·   Puntos " + ClientRpgState.skillPoints();
        int summaryRight = tree == null ? panelX + panelWidth - 16 : panelX + panelWidth - 48;
        graphics.drawString(font, Component.literal(summary), summaryRight - font.width(summary),
                panelY + 12, 0xFFE6EAF1, false);
        if (tree != null) {
            ResourceLocation emblem = new ResourceLocation("maxsekai", "textures/gui/trees/" + tree.id() + ".png");
            graphics.blit(emblem, panelX + panelWidth - 39, panelY + 5, 0, 0, 32, 32, 32, 32);
        }
        graphics.drawString(font, Component.literal("K cerrar   ·   R usar habilidad equipada"),
                panelX + 16, panelY + panelHeight - 17, 0xFF9AA9BA, false);

        if (tree == null) {
            graphics.drawCenteredString(font, "Un administrador debe asignarte una raza o don.", width / 2,
                    panelY + 112, 0xFFFFD989);
            super.render(graphics, mouseX, mouseY, partialTick);
            return;
        }

        if (activeTab == Tab.SKILLS) {
            renderSkills(graphics, tree);
        } else if (activeTab == Tab.EQUIPMENT) {
            renderEquipment(graphics, tree);
        } else {
            renderMissions(graphics);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void renderSkills(GuiGraphics graphics, SkillTree tree) {
        int leftWidth = (panelWidth - 45) * 2 / 3;
        int rowY = panelY + 94;
        graphics.drawString(font, tree.subtitle(), panelX + 16, panelY + 80, 0xFF8EDBC1);
        for (int i = 0; i < tree.skills().size(); i++) {
            SkillDefinition skill = tree.skills().get(i);
            int y = rowY + i * 38;
            int color = i == focusedSkill ? 0xFF33465A : 0xFF202B38;
            graphics.fill(panelX + 14, y - 2, panelX + 18 + leftWidth, y + 28, color);
            int skillLevel = ClientRpgState.skillLevel(skill.id());
            graphics.drawString(font, Component.literal((i + 1) + ". " + skill.name()), panelX + 22, y + 3,
                    skillLevel > 0 ? 0xFFE9F0F3 : 0xFFB5BBC4);
            graphics.drawString(font, Component.literal(skillLevel + "/99"), panelX + 22, y + 15, 0xFF8FA0B1);
            String kind = skill.ultimate() ? "DEFINITIVA" : "HABILIDAD";
            graphics.drawString(font, Component.literal(kind), panelX + 22 + leftWidth - font.width(kind) - 18,
                    y + 7, skill.ultimate() ? 0xFFFFD989 : 0xFF83C8D0);
        }
        int rightX = panelX + 28 + leftWidth;
        int rightWidth = panelWidth - (rightX - panelX) - 16;
        graphics.fill(rightX, panelY + 88, rightX + rightWidth, panelY + 318, 0x992A3746);
        SkillDefinition focused = tree.skills().get(Math.max(0, Math.min(focusedSkill, 5)));
        drawWrapped(graphics, focused.name(), rightX + 10, panelY + 100, rightWidth - 18, 0xFFFFD989);
        drawWrapped(graphics, focused.description(), rightX + 10, panelY + 124, rightWidth - 18, 0xFFE2E7EC);
        graphics.drawString(font, "Nivel: " + ClientRpgState.skillLevel(focused.id()) + "/99", rightX + 10, panelY + 195, 0xFF9EE2CC);
        graphics.drawString(font, "Enfriamiento: " + focused.cooldownTicks() / 20 + " s", rightX + 10, panelY + 211, 0xFFB6C1CC);
        graphics.drawString(font, "Duración: " + (focused.durationTicks() / 20) + " s", rightX + 10, panelY + 227, 0xFFB6C1CC);
        graphics.drawString(font, "Potencia: " + String.format("%.1f", focused.powerAt(
                Math.max(1, ClientRpgState.skillLevel(focused.id())))), rightX + 10, panelY + 243, 0xFFB6C1CC);
        int currentLevel = ClientRpgState.skillLevel(focused.id());
        String upgradeText = currentLevel >= 99 ? "Nivel máximo" :
                currentLevel == 0 ? "Aprender · 1 punto" : "Mejorar · 1 punto";
        graphics.drawString(font, upgradeText, rightX + 10, panelY + 300, 0xFF9EE2CC);
        graphics.drawString(font, "EXP: " + ClientRpgState.xp() + "/" + ClientRpgState.xpNext(),
                panelX + 16, panelY + panelHeight - 36, 0xFFD9C78C);
    }

    private void renderEquipment(GuiGraphics graphics, SkillTree tree) {
        int leftWidth = (panelWidth - 45) * 2 / 3;
        graphics.drawString(font, "Selecciona un espacio y equipa una habilidad aprendida.", panelX + 16,
                panelY + 80, 0xFF8EDBC1);
        int slot = ClientRpgState.selectedSlot();
        graphics.drawString(font, "Espacio activo: " + (slot + 1) + " · R lo activa",
                panelX + 16, panelY + 129, 0xFFFFD989);
        graphics.drawString(font, "Habilidades aprendidas", panelX + 16, panelY + 222, 0xFFCCD5DF);
        for (int i = 0; i < tree.skills().size(); i++) {
            SkillDefinition skill = tree.skills().get(i);
            if (ClientRpgState.skillLevel(skill.id()) <= 0) {
                continue;
            }
            int y = panelY + 236 + i * 27;
            graphics.drawString(font, "Niv. " + ClientRpgState.skillLevel(skill.id()), panelX + 18, y + 7, 0xFF8EDBC1);
        }
        String active = SkillDefinition.find(ClientRpgState.equipment(slot)) == null ? "vacío" :
                SkillDefinition.find(ClientRpgState.equipment(slot)).name();
        int rightX = panelX + 28 + leftWidth;
        graphics.drawString(font, "Espacio " + (slot + 1), rightX + 8, panelY + 100, 0xFFFFD989);
        drawWrapped(graphics, active, rightX + 8, panelY + 122, panelWidth - (rightX - panelX) - 28, 0xFFE2E7EC);
        graphics.drawString(font, "El enfriamiento aparece", rightX + 8, panelY + 164, 0xFFB6C1CC);
        graphics.drawString(font, "sobre la barra rápida.", rightX + 8, panelY + 178, 0xFFB6C1CC);
    }

    private void renderMissions(GuiGraphics graphics) {
        graphics.drawString(font, "Derrota monstruos hostiles para avanzar. Reclama para recibir EXP y puntos.",
                panelX + 16, panelY + 83, 0xFF8EDBC1);
        AbilityEngine.Mission[] missions = AbilityEngine.missions();
        for (int i = 0; i < missions.length; i++) {
            AbilityEngine.Mission mission = missions[i];
            int y = panelY + 122 + i * 78;
            int progress = ClientRpgState.missionProgress(i);
            graphics.fill(panelX + 14, y - 8, panelX + panelWidth - 14, y + 52, 0x992A3746);
            graphics.drawString(font, mission.title(), panelX + 26, y, 0xFFFFD989);
            drawWrapped(graphics, mission.description(), panelX + 26, y + 17, panelWidth - 245, 0xFFE2E7EC);
            graphics.drawString(font, Math.min(progress, mission.requirement()) + "/" + mission.requirement() +
                    "  ·  " + mission.xpReward() + " EXP  ·  " + mission.pointReward() + " puntos",
                    panelX + 26, y + 36, 0xFF9EE2CC);
        }
    }

    private void drawWrapped(GuiGraphics graphics, String text, int x, int y, int maxWidth, int color) {
        String remaining = text;
        int currentY = y;
        while (!remaining.isEmpty()) {
            int cut = Math.min(remaining.length(), Math.max(1, maxWidth / 6));
            while (cut < remaining.length() && font.width(remaining.substring(0, cut + 1)) <= maxWidth) {
                cut++;
            }
            if (cut < remaining.length()) {
                int space = remaining.lastIndexOf(' ', cut);
                if (space > 0) {
                    cut = space;
                }
            }
            graphics.drawString(font, remaining.substring(0, cut), x, currentY, color);
            remaining = remaining.substring(cut).stripLeading();
            currentY += 12;
            if (currentY > panelY + panelHeight - 45) {
                return;
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClientModEvents.OPEN_MENU.matches(keyCode, scanCode) || keyCode == 256) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
