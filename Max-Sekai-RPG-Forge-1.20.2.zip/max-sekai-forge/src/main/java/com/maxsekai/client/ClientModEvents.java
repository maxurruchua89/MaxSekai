package com.maxsekai.client;

import com.maxsekai.MaxSekaiMod;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = MaxSekaiMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    public static final KeyMapping OPEN_MENU = new KeyMapping("key.maxsekai.menu",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.maxsekai");
    public static final KeyMapping CAST_SKILL = new KeyMapping("key.maxsekai.cast",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.maxsekai");

    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU);
        event.register(CAST_SKILL);
    }
}
