package com.maxsekai.client;

import com.maxsekai.skill.SkillDefinition;
import com.maxsekai.skill.SkillTree;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClientRpgState {
    private static CompoundTag data = new CompoundTag();

    private ClientRpgState() {}

    public static void update(CompoundTag freshData) {
        data = freshData.copy();
    }

    public static void tick() {
        CompoundTag cooldowns = data.getCompound("cooldowns_remaining");
        for (SkillTree tree : SkillTree.values()) {
            for (SkillDefinition skill : tree.skills()) {
                int remaining = cooldowns.getInt(skill.id());
                if (remaining > 0) {
                    cooldowns.putInt(skill.id(), remaining - 1);
                }
            }
        }
        data.put("cooldowns_remaining", cooldowns);
    }

    public static String treeId() {
        return data.getString("tree");
    }

    public static SkillTree tree() {
        return SkillTree.fromId(treeId());
    }

    public static int level() {
        return Math.max(1, data.getInt("level"));
    }

    public static int xp() {
        return Math.max(0, data.getInt("xp"));
    }

    public static int xpNext() {
        return Math.max(100, 100 + (level() - 1) * 25);
    }

    public static int skillPoints() {
        return Math.max(0, data.getInt("skillPoints"));
    }

    public static int skillLevel(String skillId) {
        return data.getCompound("skillLevels").getInt(skillId);
    }

    public static String equipment(int slot) {
        return data.getCompound("equipment").getString(Integer.toString(slot));
    }

    public static int selectedSlot() {
        return Math.max(0, Math.min(3, data.getInt("selectedSlot")));
    }

    public static int missionProgress(int mission) {
        return Math.max(0, data.getInt("mission_" + mission));
    }

    public static int cooldownTicks(String skillId) {
        return Math.max(0, data.getCompound("cooldowns_remaining").getInt(skillId));
    }

    public static CompoundTag copy() {
        return data.copy();
    }
}
