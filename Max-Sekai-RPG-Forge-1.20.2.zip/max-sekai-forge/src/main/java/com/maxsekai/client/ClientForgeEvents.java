package com.maxsekai.client;

import com.maxsekai.MaxSekaiMod;
import com.maxsekai.network.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MaxSekaiMod.MOD_ID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        ClientRpgState.tick();
        Minecraft minecraft = Minecraft.getInstance();
        while (ClientModEvents.OPEN_MENU.consumeClick()) {
            if (minecraft.screen instanceof MaxSekaiScreen) {
                minecraft.setScreen(null);
            } else if (minecraft.screen == null) {
                minecraft.setScreen(new MaxSekaiScreen());
            }
        }
        while (ClientModEvents.CAST_SKILL.consumeClick()) {
            if (minecraft.player != null && minecraft.screen == null) {
                NetworkHandler.CHANNEL.send(new NetworkHandler.CastPacket(),
                        net.minecraftforge.network.PacketDistributor.SERVER.noArg());
            }
        }
    }

    @SubscribeEvent
    public static void renderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.HOTBAR.id())) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        var tree = ClientRpgState.tree();
        if (tree == null) {
            return;
        }
        String skillId = ClientRpgState.equipment(ClientRpgState.selectedSlot());
        var skill = com.maxsekai.skill.SkillDefinition.find(skillId);
        if (skill == null) {
            return;
        }
        int remaining = ClientRpgState.cooldownTicks(skillId);
        String label = skill.name() + (remaining > 0 ? "  " + String.format("%.1fs", remaining / 20.0) : "  LISTA");
        int x = (event.getWindow().getGuiScaledWidth() - minecraft.font.width(label)) / 2;
        int y = event.getWindow().getGuiScaledHeight() - 54;
        event.getGuiGraphics().fill(x - 6, y - 3, x + minecraft.font.width(label) + 6, y + 13, 0xBB10131D);
        event.getGuiGraphics().drawString(minecraft.font, Component.literal(label), x, y, remaining > 0 ? 0xFFB5B5B5 : 0xFF78F0C2);
    }
}
