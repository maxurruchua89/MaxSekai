package com.maxsekai.command;

import com.maxsekai.data.PlayerRpgData;
import com.maxsekai.network.NetworkHandler;
import com.maxsekai.skill.SkillTree;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;

public final class MaxSekaiCommands {
    private MaxSekaiCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("maxsekai")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("asignar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .then(Commands.argument("don", StringArgumentType.word())
                                        .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                                Arrays.stream(SkillTree.values()).map(SkillTree::id), builder))
                                        .executes(context -> {
                                            ServerPlayer target = EntityArgument.getPlayer(context, "jugador");
                                            String treeId = StringArgumentType.getString(context, "don");
                                            SkillTree tree = SkillTree.fromId(treeId);
                                            if (tree == null) {
                                                context.getSource().sendFailure(Component.literal("Don desconocido."));
                                                return 0;
                                            }
                                            target.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
                                                data.assignTree(tree.id());
                                                NetworkHandler.sync(target);
                                            });
                                            context.getSource().sendSuccess(() -> Component.literal(
                                                    "Árbol " + tree.title() + " asignado a " + target.getGameProfile().getName() + "."),
                                                    true);
                                            return 1;
                                        }))))
                .then(Commands.literal("puntos")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .then(Commands.argument("cantidad", IntegerArgumentType.integer(1, 1_000_000))
                                        .executes(context -> {
                                            ServerPlayer target = EntityArgument.getPlayer(context, "jugador");
                                            int amount = IntegerArgumentType.getInteger(context, "cantidad");
                                            target.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> data.addSkillPoints(amount));
                                            NetworkHandler.sync(target);
                                            context.getSource().sendSuccess(() -> Component.literal(
                                                    "Se otorgaron " + amount + " puntos a " + target.getGameProfile().getName() + "."), true);
                                            return 1;
                                        }))))
                .then(Commands.literal("xp")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .then(Commands.argument("cantidad", IntegerArgumentType.integer(1, 10_000_000))
                                        .executes(context -> {
                                            ServerPlayer target = EntityArgument.getPlayer(context, "jugador");
                                            int amount = IntegerArgumentType.getInteger(context, "cantidad");
                                            target.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> data.addXp(amount));
                                            NetworkHandler.sync(target);
                                            context.getSource().sendSuccess(() -> Component.literal(
                                                    "Se otorgaron " + amount + " EXP a " + target.getGameProfile().getName() + "."), true);
                                            return 1;
                                        }))))
                .then(Commands.literal("nivel")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(context -> {
                                    ServerPlayer target = EntityArgument.getPlayer(context, "jugador");
                                    target.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data ->
                                            context.getSource().sendSuccess(() -> Component.literal(
                                                    target.getGameProfile().getName() + " es nivel " + data.getLevel() +
                                                            " (" + data.getXp() + "/" + data.getXpForNextLevel() + " EXP)."), false));
                                    return 1;
                                })))
                .then(Commands.literal("reset")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(context -> {
                                    ServerPlayer target = EntityArgument.getPlayer(context, "jugador");
                                    target.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> data.reset());
                                    NetworkHandler.sync(target);
                                    context.getSource().sendSuccess(() -> Component.literal(
                                            "Progreso RPG reiniciado para " + target.getGameProfile().getName() + "."), true);
                                    return 1;
                                }))));
    }
}
