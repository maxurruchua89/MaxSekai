package com.maxsekai;

import com.maxsekai.command.MaxSekaiCommands;
import com.maxsekai.data.PlayerRpgDataProvider;
import com.maxsekai.network.NetworkHandler;
import com.maxsekai.skill.AbilityEngine;
import com.maxsekai.skill.SkillTree;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MaxSekaiMod.MOD_ID)
public final class MaxSekaiMod {
    public static final String MOD_ID = "maxsekai";
    public static final ResourceLocation PLAYER_DATA_ID = new ResourceLocation(MOD_ID, "rpg_data");

    public MaxSekaiMod() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::registerCapabilities);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(com.maxsekai.data.IPlayerRpgData.class);
    }

    @SubscribeEvent
    public void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            PlayerRpgDataProvider provider = new PlayerRpgDataProvider();
            event.addCapability(PLAYER_DATA_ID, provider);
            event.addListener(provider::invalidate);
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(com.maxsekai.data.PlayerRpgData.CAPABILITY).ifPresent(source ->
                event.getEntity().getCapability(com.maxsekai.data.PlayerRpgData.CAPABILITY).ifPresent(target ->
                        target.deserializeNBT(source.serializeNBT())));
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        MaxSekaiCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        AbilityEngine.handleMobKill(event);
    }

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        AbilityEngine.expireSummon(event.getEntity());
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) {
            return;
        }
        if (event.player.tickCount % 10 == 0 && event.player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            NetworkHandler.sync(serverPlayer);
        }
    }
}
