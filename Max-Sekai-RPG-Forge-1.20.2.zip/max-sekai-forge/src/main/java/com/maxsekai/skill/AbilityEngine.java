package com.maxsekai.skill;

import com.maxsekai.MaxSekaiMod;
import com.maxsekai.data.IPlayerRpgData;
import com.maxsekai.data.PlayerRpgData;
import com.maxsekai.network.NetworkHandler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import java.util.List;
import java.util.function.Consumer;

public final class AbilityEngine {
    private static final String SUMMON_EXPIRY = MaxSekaiMod.MOD_ID + "_summon_expiry";
    private static final Mission[] MISSIONS = {
            new Mission("Cazador de monstruos", "Derrota 10 monstruos hostiles", 10, 250, 2),
            new Mission("Purga de no-muertos", "Derrota 5 criaturas no-muertas", 5, 180, 2),
            new Mission("Amenaza erradicada", "Derrota 20 criaturas hostiles", 20, 500, 4)
    };

    private AbilityEngine() {}

    public static void tryCast(ServerPlayer player) {
        player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
            SkillTree tree = SkillTree.fromId(data.getTreeId());
            String skillId = data.getEquipment(data.getSelectedSlot());
            SkillDefinition skill = SkillDefinition.find(skillId);
            int skillLevel = data.getSkillLevel(skillId);
            if (tree == null || skill == null || !tree.contains(skillId) || skillLevel <= 0) {
                player.displayClientMessage(Component.literal("No tienes una habilidad válida equipada en ese espacio."), true);
                return;
            }
            long now = player.getServer().overworld().getGameTime();
            long cooldownUntil = data.getCooldownUntil(skillId);
            if (cooldownUntil > now) {
                player.displayClientMessage(Component.literal("Enfriamiento: " +
                        String.format("%.1f", (cooldownUntil - now) / 20.0) + " s"), true);
                return;
            }

            execute(player, tree, skill, skillLevel);
            data.setCooldownUntil(skillId, now + skill.cooldownAt(skillLevel));
            NetworkHandler.sync(player);
        });
    }

    private static void execute(ServerPlayer player, SkillTree tree, SkillDefinition skill, int level) {
        float power = skill.powerAt(level);
        int duration = skill.durationAt(level);
        ServerLevel serverLevel = (ServerLevel) player.level();
        LivingEntity target;
        switch (skill.id()) {
            case "invocacion_menor" -> summonWolves(player, 1, duration, power);
            case "lobo_espiritual" -> summonWolves(player, 2, duration, power);
            case "guardianes_gemelos" -> {
                summonWolves(player, 2, duration, power);
                buff(player, net.minecraft.world.effect.MobEffects.ABSORPTION, duration, 1, level);
            }
            case "bestia_arcana" -> summonWolves(player, 1, duration, power * 1.7f);
            case "ejercito_espiritual" -> {
                summonWolves(player, 4, duration, power);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 0, level);
            }
            case "rey_invocaciones" -> {
                summonWolves(player, 6, duration, power * 1.4f);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
            }

            case "chispa_elemental", "llama_draconica" -> {
                target = findTargetInSight(player, 22.0);
                hit(player, target, power, 4);
                particles(serverLevel, ParticleTypes.FLAME, player.position().add(0, 1, 0), 22, 0.4, 0.5, 0.4, 0.03);
            }
            case "afinidad_elemental" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, duration, 0, level);
            }
            case "onda_elemental" -> areaDamage(player, 5.5, power, 0, false);
            case "armadura_elemental" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.ABSORPTION, duration, 0, level);
            }
            case "tormenta_elemental" -> areaDamage(player, 8.0, power, 2, false);
            case "cataclismo_elemental" -> {
                areaDamage(player, 8.5, power * 1.15f, 0, true);
                player.level().explode(player, player.getX(), player.getY(), player.getZ(), 2.2f,
                        Level.ExplosionInteraction.NONE);
            }

            case "toque_curativo" -> healAllies(player, 6.0, power, false);
            case "luz_restauradora" -> healAllies(player, 9.0, power, true);
            case "barrera_sagrada" -> protectAllies(player, 8.0, duration, level);
            case "purificacion" -> purifyAllies(player, 8.0, power);
            case "zona_curacion" -> healAllies(player, 12.0, power, true);
            case "milagro_vida" -> healAllies(player, 15.0, power * 1.6f, true);

            case "corte_rapido", "golpe_forge", "garras_bestiales" -> {
                target = findNearestTarget(player, 4.0);
                hit(player, target, power, 0);
            }
            case "paso_relampago" -> {
                Vec3 look = player.getLookAngle();
                player.push(look.x * 1.25, 0.12, look.z * 1.25);
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
                player.hurtMarked = true;
            }
            case "doble_filo" -> {
                target = findNearestTarget(player, 4.5);
                hit(player, target, power, 0);
                if (target != null && target.isAlive()) {
                    target.hurt(player.damageSources().playerAttack(player), power * 0.8f);
                }
            }
            case "danza_espadas" -> {
                for (int i = 0; i < 3; i++) {
                    areaDamage(player, 4.5, power * 0.55f, 0, false);
                }
            }
            case "instinto_espadachin" -> {
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
            }
            case "corte_vacio" -> areaDamage(player, 10.0, power, 0, true);

            case "vision_elfica", "sentidos_nocturnos" ->
                    buff(player, net.minecraft.world.effect.MobEffects.NIGHT_VISION, duration, 0, level);
            case "raices" -> areaDebuff(player, 6.0, net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                    scaledDuration(duration, level), 2);
            case "bendicion_natural" -> {
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.REGENERATION, duration, 0, level);
            }
            case "espinas_bosque" -> areaDamage(player, 6.0, power, 2, false);
            case "espiritu_bosque" -> {
                summonWolves(player, 1, duration, power);
                healAllies(player, 6.0, power * 0.5f, false);
            }
            case "guardian_ancestral" -> {
                summonWolves(player, 3, duration, power);
                buff(player, net.minecraft.world.effect.MobEffects.REGENERATION, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 0, level);
            }

            case "instinto_salvaje" -> {
                buff(player, net.minecraft.world.effect.MobEffects.NIGHT_VISION, duration, 0, level);
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
            }
            case "fuerza_animal" -> buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
            case "transformacion_parcial" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 0, level);
            }
            case "transformacion_completa" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 2, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
            }
            case "bestia_ancestral" -> {
                summonWolves(player, 3, duration, power * 1.2f);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
            }

            case "escamas_resistentes", "cuerpo_resistente" ->
                    buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
            case "resistencia_calor" -> buff(player, net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, duration, 0, level);
            case "aliento_dragon" -> {
                target = findTargetInSight(player, 14.0);
                hit(player, target, power, 5);
                areaDamage(player, 4.0, power * 0.55f, 4, true);
            }
            case "armadura_draconica" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, duration, 0, level);
            }
            case "despertar_draconico" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 2, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, duration, 0, level);
                areaDamage(player, 7.0, power, 5, true);
            }

            case "sentido_minero" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DIG_SPEED, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.LUCK, duration, 0, level);
            }
            case "armadura_reforzada" ->
                    buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 2, level);
            case "maestro_artesano" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DIG_SPEED, duration, 2, level);
                buff(player, net.minecraft.world.effect.MobEffects.LUCK, duration, 1, level);
            }
            case "forja_ancestral" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                areaDamage(player, 6.0, power, 0, true);
            }

            case "cuerpo_etero", "forma_murcielago" -> {
                buff(player, net.minecraft.world.effect.MobEffects.INVISIBILITY, duration, 0, level);
                buff(player, net.minecraft.world.effect.MobEffects.SLOW_FALLING, duration, 0, level);
                if (skill.id().equals("forma_murcielago")) {
                    buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 2, level);
                }
            }
            case "proyectil_espiritual", "lanzas_carmesi" -> {
                target = findTargetInSight(player, 22.0);
                hit(player, target, power, 0);
                particles(serverLevel, ParticleTypes.SOUL, player.position().add(0, 1, 0), 24, 0.45, 0.45, 0.45, 0.04);
            }
            case "afinidad_espiritual" -> {
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 0, level);
            }
            case "barrera_energia" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.ABSORPTION, duration, 1, level);
            }
            case "conexion_espiritual" -> healAllies(player, 9.0, power, true);
            case "espiritu_primordial" -> {
                areaDamage(player, 8.0, power, 0, true);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
            }

            case "velocidad_vampirica" ->
                    buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 2, level);
            case "regeneracion_vampirica" -> {
                player.heal(Math.min(player.getMaxHealth(), power * 0.6f));
                buff(player, net.minecraft.world.effect.MobEffects.REGENERATION, duration, 1, level);
            }
            case "senor_noche" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, duration, 2, level);
                buff(player, net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, duration, 2, level);
                buff(player, net.minecraft.world.effect.MobEffects.REGENERATION, duration, 1, level);
            }

            case "adaptacion_acuatica" -> {
                buff(player, net.minecraft.world.effect.MobEffects.WATER_BREATHING, duration, 0, level);
                buff(player, net.minecraft.world.effect.MobEffects.NIGHT_VISION, duration, 0, level);
            }
            case "chorro_agua" -> {
                target = findTargetInSight(player, 18.0);
                hit(player, target, power, 0);
                if (target != null) {
                    target.knockback(0.8, player.getX() - target.getX(), player.getZ() - target.getZ());
                }
                particles(serverLevel, ParticleTypes.SPLASH, player.position().add(0, 1, 0), 28, 0.5, 0.5, 0.5, 0.1);
            }
            case "corriente_marina" -> pushArea(player, 6.0, 1.3);
            case "prision_agua" -> {
                areaDebuff(player, 5.0, net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                        scaledDuration(100, level), 3);
                areaDebuff(player, 5.0, net.minecraft.world.effect.MobEffects.WEAKNESS,
                        scaledDuration(100, level), 0);
            }
            case "marea_protectora" -> {
                buff(player, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
                buff(player, net.minecraft.world.effect.MobEffects.WATER_BREATHING, duration, 0, level);
            }
            case "senor_mareas" -> {
                areaDamage(player, 9.0, power, 0, true);
                healAllies(player, 10.0, power, false);
                particles(serverLevel, ParticleTypes.SPLASH, player.position().add(0, 1, 0), 60, 2.5, 1.2, 2.5, 0.15);
            }

            default -> {
                player.displayClientMessage(Component.literal("La habilidad no tiene un efecto registrado."), true);
                return;
            }
        }

        serverLevel.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundSource.PLAYERS, 0.8f, skill.ultimate() ? 0.75f : 1.0f);
        particles(serverLevel, tree == SkillTree.MERFOLK ? ParticleTypes.SPLASH :
                        tree == SkillTree.SUMMONER || tree == SkillTree.SPIRIT ? ParticleTypes.SOUL :
                                tree == SkillTree.HEALER ? ParticleTypes.HEART : ParticleTypes.ENCHANT,
                player.position().add(0, 1, 0), skill.ultimate() ? 38 : 18, 0.8, 0.8, 0.8, 0.08);
    }

    public static void handleMobKill(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player) ||
                !(event.getEntity() instanceof Monster monster)) {
            return;
        }
        player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
            int reward = Math.max(8, Math.min(100, Math.round(monster.getMaxHealth() * 1.4f)));
            data.addXp(reward);
            data.addMissionProgress(0, 1);
            data.addMissionProgress(2, 1);
            if (monster.getMobType() == MobType.UNDEAD) {
                data.addMissionProgress(1, 1);
            }
            player.displayClientMessage(Component.literal("+" + reward + " EXP"), true);
            NetworkHandler.sync(player);
        });
    }

    public static void claimMission(ServerPlayer player, int missionIndex) {
        if (missionIndex < 0 || missionIndex >= MISSIONS.length) {
            return;
        }
        Mission mission = MISSIONS[missionIndex];
        player.getCapability(PlayerRpgData.CAPABILITY).ifPresent(data -> {
            if (!data.claimMission(missionIndex, mission.requirement())) {
                player.displayClientMessage(Component.literal("La misión todavía no está completa."), true);
                return;
            }
            data.addXp(mission.xpReward());
            data.addSkillPoints(mission.pointReward());
            player.displayClientMessage(Component.literal("Misión completada: +" + mission.xpReward() +
                    " EXP y +" + mission.pointReward() + " puntos."), true);
            NetworkHandler.sync(player);
        });
    }

    public static Mission[] missions() {
        return MISSIONS.clone();
    }

    public static void expireSummon(LivingEntity entity) {
        if (entity.level().isClientSide || !entity.getPersistentData().contains(SUMMON_EXPIRY)) {
            return;
        }
        if (entity.level().getGameTime() >= entity.getPersistentData().getLong(SUMMON_EXPIRY)) {
            entity.remove(Entity.RemovalReason.DISCARDED);
        }
    }

    private static void summonWolves(ServerPlayer player, int count, int durationTicks, float power) {
        ServerLevel level = (ServerLevel) player.level();
        LivingEntity target = findNearestTarget(player, 18.0);
        for (int i = 0; i < count; i++) {
            Wolf wolf = net.minecraft.world.entity.EntityType.WOLF.create(level);
            if (wolf == null) {
                continue;
            }
            double angle = (Math.PI * 2 * i) / Math.max(1, count);
            wolf.moveTo(player.getX() + Math.cos(angle) * 1.7, player.getY(), player.getZ() + Math.sin(angle) * 1.7,
                    player.getYRot(), 0);
            wolf.setTame(true);
            wolf.setOwnerUUID(player.getUUID());
            wolf.setPersistenceRequired();
            if (wolf.getAttribute(Attributes.MAX_HEALTH) != null) {
                wolf.getAttribute(Attributes.MAX_HEALTH).setBaseValue(Math.min(40.0, 8.0 + power * 0.55));
                wolf.setHealth(wolf.getMaxHealth());
            }
            if (wolf.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
                wolf.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(Math.min(18.0, 4.0 + power * 0.32));
            }
            wolf.setCustomName(Component.literal("Lobo espiritual"));
            wolf.getPersistentData().putLong(SUMMON_EXPIRY, level.getGameTime() + Math.max(200, durationTicks));
            if (target != null) {
                wolf.setTarget(target);
            }
            level.addFreshEntity(wolf);
        }
        particles(level, ParticleTypes.SOUL, player.position().add(0, 1, 0), 32, 1.2, 0.8, 1.2, 0.06);
        player.displayClientMessage(Component.literal("Has invocado " + count + " espíritu(s)."), true);
    }

    private static LivingEntity findNearestTarget(ServerPlayer player, double range) {
        AABB area = player.getBoundingBox().inflate(range);
        return player.level().getEntitiesOfClass(LivingEntity.class, area, entity -> validTarget(player, entity))
                .stream().min((a, b) -> Double.compare(a.distanceToSqr(player), b.distanceToSqr(player))).orElse(null);
    }

    private static LivingEntity findTargetInSight(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        return player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(range),
                        entity -> validTarget(player, entity) && entity.distanceTo(player) <= range)
                .stream()
                .filter(entity -> entity.getBoundingBox().getCenter().subtract(eye).normalize().dot(look) > 0.78)
                .min((a, b) -> Double.compare(a.distanceToSqr(player), b.distanceToSqr(player)))
                .orElseGet(() -> findNearestTarget(player, Math.min(range, 4.5)));
    }

    private static boolean validTarget(Player player, LivingEntity entity) {
        return entity.isAlive() && entity != player && !(entity instanceof Player) &&
                !entity.isAlliedTo(player) && !(entity instanceof Wolf wolf && wolf.isTame());
    }

    private static void hit(ServerPlayer player, LivingEntity target, float damage, int fireSeconds) {
        if (target == null || !target.isAlive()) {
            player.displayClientMessage(Component.literal("No hay un enemigo en el alcance."), true);
            return;
        }
        target.hurt(player.damageSources().playerAttack(player), damage);
        if (fireSeconds > 0 && target.isAlive()) {
            target.setSecondsOnFire(fireSeconds);
        }
        target.knockback(0.45, player.getX() - target.getX(), player.getZ() - target.getZ());
    }

    private static void areaDamage(ServerPlayer player, double radius, float damage, int slownessSeconds, boolean ultimate) {
        AABB area = player.getBoundingBox().inflate(radius);
        List<LivingEntity> targets = player.level().getEntitiesOfClass(LivingEntity.class, area,
                entity -> validTarget(player, entity) && entity.distanceTo(player) <= radius);
        for (LivingEntity target : targets) {
            target.hurt(player.damageSources().playerAttack(player), damage);
            if (slownessSeconds > 0 && target.isAlive()) {
                target.addEffect(new MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                        slownessSeconds * 20, 1, false, true));
            }
            if (ultimate && target.isAlive()) {
                target.knockback(0.8, player.getX() - target.getX(), player.getZ() - target.getZ());
            }
        }
    }

    private static void areaDebuff(ServerPlayer player, double radius, MobEffect effect, int duration, int amplifier) {
        for (LivingEntity target : player.level().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(radius), entity -> validTarget(player, entity))) {
            target.addEffect(new MobEffectInstance(effect, duration, amplifier, false, true));
        }
    }

    private static void healAllies(ServerPlayer player, double radius, float amount, boolean regeneration) {
        for (Player ally : player.level().getEntitiesOfClass(Player.class, player.getBoundingBox().inflate(radius),
                candidate -> candidate.isAlive() && candidate.distanceTo(player) <= radius)) {
            ally.heal(amount);
            if (regeneration) {
                ally.addEffect(new MobEffectInstance(net.minecraft.world.effect.MobEffects.REGENERATION, 100, 0, false, true));
            }
            particles((ServerLevel) ally.level(), ParticleTypes.HEART, ally.position().add(0, 1.3, 0), 8, 0.35, 0.4, 0.35, 0.03);
        }
    }

    private static void protectAllies(ServerPlayer player, double radius, int duration, int level) {
        for (Player ally : player.level().getEntitiesOfClass(Player.class, player.getBoundingBox().inflate(radius),
                candidate -> candidate.isAlive() && candidate.distanceTo(player) <= radius)) {
            buff(ally, net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, duration, 1, level);
            buff(ally, net.minecraft.world.effect.MobEffects.ABSORPTION, duration, 0, level);
        }
    }

    private static void purifyAllies(ServerPlayer player, double radius, float heal) {
        List<MobEffect> negativeEffects = List.of(
                net.minecraft.world.effect.MobEffects.POISON,
                net.minecraft.world.effect.MobEffects.WITHER,
                net.minecraft.world.effect.MobEffects.WEAKNESS,
                net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                net.minecraft.world.effect.MobEffects.BLINDNESS,
                net.minecraft.world.effect.MobEffects.HUNGER,
                net.minecraft.world.effect.MobEffects.CONFUSION
        );
        for (Player ally : player.level().getEntitiesOfClass(Player.class, player.getBoundingBox().inflate(radius),
                candidate -> candidate.isAlive() && candidate.distanceTo(player) <= radius)) {
            negativeEffects.forEach(ally::removeEffect);
            ally.heal(heal);
        }
    }

    private static void pushArea(ServerPlayer player, double radius, double strength) {
        for (LivingEntity target : player.level().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(radius), entity -> validTarget(player, entity))) {
            target.knockback(strength, player.getX() - target.getX(), player.getZ() - target.getZ());
            target.hurtMarked = true;
        }
        particles((ServerLevel) player.level(), ParticleTypes.SPLASH, player.position().add(0, 1, 0),
                36, 1.8, 0.8, 1.8, 0.1);
    }

    private static void buff(LivingEntity entity, MobEffect effect, int duration, int baseAmplifier, int skillLevel) {
        int amplifier = Math.min(3, baseAmplifier + Math.max(0, skillLevel - 1) / 35);
        entity.addEffect(new MobEffectInstance(effect, Math.max(20, duration), amplifier, false, true));
    }

    private static int scaledDuration(int baseTicks, int level) {
        return baseTicks + Math.max(0, level - 1) * 8;
    }

    private static void particles(ServerLevel level, net.minecraft.core.particles.ParticleOptions type, Vec3 position,
                                  int count, double x, double y, double z, double speed) {
        level.sendParticles(type, position.x, position.y, position.z, count, x, y, z, speed);
    }

    public record Mission(String title, String description, int requirement, int xpReward, int pointReward) {}
}
