package com.maxsekai.skill;

import java.util.Arrays;
import java.util.Optional;

public record SkillDefinition(
        String id,
        String name,
        String description,
        int cooldownTicks,
        int durationTicks,
        float basePower,
        float powerPerLevel,
        boolean ultimate
) {
    public static Optional<SkillDefinition> findOptional(String id) {
        return Arrays.stream(SkillTree.values())
                .flatMap(tree -> tree.skills().stream())
                .filter(skill -> skill.id().equals(id))
                .findFirst();
    }

    public static SkillDefinition find(String id) {
        if (id == null || id.isBlank()) {
            return null;
        }
        return findOptional(id).orElse(null);
    }

    public float powerAt(int level) {
        int safeLevel = Math.max(1, Math.min(99, level));
        return basePower + (safeLevel - 1) * powerPerLevel;
    }

    public int durationAt(int level) {
        return Math.max(20, durationTicks + Math.max(0, Math.min(98, level - 1)) * 5);
    }

    public int cooldownAt(int level) {
        int safeLevel = Math.max(1, Math.min(99, level));
        double reduction = Math.min(0.45, (safeLevel - 1) * 0.0035);
        return Math.max(20, (int) (cooldownTicks * (1.0 - reduction)));
    }
}
