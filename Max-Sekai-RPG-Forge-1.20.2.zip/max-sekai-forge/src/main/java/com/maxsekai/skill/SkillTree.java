package com.maxsekai.skill;

import java.util.List;

import static com.maxsekai.skill.SkillDefinition.*;

public enum SkillTree {
    SUMMONER("invocador", "Invocador", "Vínculos con criaturas espirituales", List.of(
            s("invocacion_menor", "Invocación menor", "Invoca un lobo espiritual que lucha a tu lado durante un tiempo.", 18, 45, 2, 0.08f, false),
            s("lobo_espiritual", "Lobo espiritual", "Invoca dos lobos espirituales más resistentes.", 28, 60, 3, 0.12f, false),
            s("guardianes_gemelos", "Guardianes gemelos", "Llama dos guardianes y obtiene una barrera de absorción.", 40, 75, 5, 0.15f, false),
            s("bestia_arcana", "Bestia arcana", "Invoca una bestia espiritual de gran fuerza.", 55, 90, 7, 0.18f, false),
            s("ejercito_espiritual", "Ejército espiritual", "Convoca cuatro lobos y refuerza tu resistencia.", 85, 100, 9, 0.22f, false),
            s("rey_invocaciones", "Rey de las invocaciones", "Invoca una guardia espiritual y recibe poder y protección.", 180, 120, 14, 0.30f, true)
    )),
    ELEMENTAL_MAGE("mago_elemental", "Mago elemental", "Dominio ofensivo de los elementos", List.of(
            s("chispa_elemental", "Chispa elemental", "Dispara una descarga que daña e incendia al objetivo cercano.", 12, 0, 5, 0.18f, false),
            s("afinidad_elemental", "Afinidad elemental", "Aumenta el poder de ataque y protege contra el fuego.", 35, 18, 0, 0, false),
            s("onda_elemental", "Onda elemental", "Libera una onda dañina alrededor del lanzador.", 30, 0, 7, 0.24f, false),
            s("armadura_elemental", "Armadura elemental", "Concentra energía elemental en una defensa temporal.", 42, 22, 0, 0, false),
            s("tormenta_elemental", "Tormenta elemental", "Golpea a los enemigos cercanos y los ralentiza.", 70, 0, 10, 0.30f, false),
            s("cataclismo_elemental", "Cataclismo elemental", "Desata una explosión de gran potencia sin destruir bloques.", 200, 0, 18, 0.42f, true)
    )),
    HEALER("sanador", "Sanador", "Restauración y protección sin resurrección", List.of(
            s("toque_curativo", "Toque curativo", "Restaura salud al jugador y a aliados cercanos.", 15, 0, 5, 0.12f, false),
            s("luz_restauradora", "Luz restauradora", "Cura a varios aliados en el área y aplica regeneración.", 32, 0, 7, 0.16f, false),
            s("barrera_sagrada", "Barrera sagrada", "Otorga resistencia y absorción temporal a aliados cercanos.", 45, 24, 0, 0, false),
            s("purificacion", "Purificación", "Elimina efectos negativos del usuario y de aliados cercanos.", 38, 0, 4, 0.10f, false),
            s("zona_curacion", "Zona de curación", "Restaura salud y aplica regeneración en un área amplia.", 75, 0, 9, 0.18f, false),
            s("milagro_vida", "Milagro de vida", "Cura profundamente a los vivos cercanos; no resucita muertos.", 210, 0, 16, 0.28f, true)
    )),
    SWORDSMAN("espadachin_veloz", "Espadachín veloz", "Movilidad y daño de corto alcance", List.of(
            s("corte_rapido", "Corte rápido", "Golpea al enemigo más próximo con un tajo veloz.", 10, 0, 6, 0.20f, false),
            s("paso_relampago", "Paso relámpago", "Impulsa al espadachín hacia delante y le da velocidad.", 14, 5, 0, 0, false),
            s("doble_filo", "Doble filo", "Ataca dos veces al objetivo más próximo.", 22, 0, 5, 0.17f, false),
            s("danza_espadas", "Danza de espadas", "Ejecuta una secuencia de cortes contra enemigos próximos.", 42, 0, 8, 0.23f, false),
            s("instinto_espadachin", "Instinto del espadachín", "Mejora temporalmente la velocidad y la fuerza.", 55, 25, 0, 0, false),
            s("corte_vacio", "Corte del vacío", "Un tajo definitivo alcanza y daña a varios enemigos cercanos.", 180, 0, 16, 0.38f, true)
    )),
    ELF("elfo", "Elfo", "Afinidad con la naturaleza y el bosque", List.of(
            s("vision_elfica", "Visión élfica", "Mejora la visión en la oscuridad durante un tiempo.", 22, 45, 0, 0, false),
            s("raices", "Raíces", "Ralentiza a los enemigos cercanos como si los sujetaran raíces.", 28, 0, 4, 0.10f, false),
            s("bendicion_natural", "Bendición natural", "Concede velocidad y regeneración al usuario.", 38, 24, 0, 0, false),
            s("espinas_bosque", "Espinas del bosque", "Hiere y ralentiza a los enemigos que rodean al elfo.", 45, 0, 7, 0.20f, false),
            s("espiritu_bosque", "Espíritu del bosque", "Invoca un compañero lobo y restaura salud.", 65, 80, 7, 0.18f, false),
            s("guardian_ancestral", "Guardián ancestral", "Invoca guardianes y protege al elfo con regeneración.", 180, 120, 14, 0.30f, true)
    )),
    BEAST("bestia", "Bestia", "Instinto, fuerza y transformación", List.of(
            s("instinto_salvaje", "Instinto salvaje", "Agudiza los sentidos nocturnos y mejora la velocidad.", 25, 30, 0, 0, false),
            s("garras_bestiales", "Garras bestiales", "Desgarra al objetivo más próximo.", 12, 0, 6, 0.20f, false),
            s("fuerza_animal", "Fuerza animal", "Aumenta temporalmente el daño cuerpo a cuerpo.", 38, 24, 0, 0, false),
            s("transformacion_parcial", "Transformación parcial", "Aumenta fuerza y resistencia durante la transformación.", 50, 28, 0, 0, false),
            s("transformacion_completa", "Transformación completa", "Otorga fuerza, resistencia y velocidad superiores.", 85, 38, 0, 0, false),
            s("bestia_ancestral", "Bestia ancestral", "Despierta el poder ancestral e invoca espíritus aliados.", 190, 100, 16, 0.32f, true)
    )),
    DRACONID("draconido", "Dracónido", "Escamas, fuego y poder dracónico", List.of(
            s("escamas_resistentes", "Escamas resistentes", "Refuerza la defensa con resistencia temporal.", 28, 24, 0, 0, false),
            s("llama_draconica", "Llama dracónica", "Quema y daña al enemigo cercano.", 16, 0, 7, 0.22f, false),
            s("resistencia_calor", "Resistencia al calor", "Otorga inmunidad al fuego temporal.", 30, 60, 0, 0, false),
            s("aliento_dragon", "Aliento de dragón", "Lanza una ráfaga ardiente contra enemigos próximos.", 48, 0, 10, 0.28f, false),
            s("armadura_draconica", "Armadura dracónica", "Combina resistencia y protección contra el fuego.", 66, 35, 0, 0, false),
            s("despertar_draconico", "Despertar dracónico", "Desata poder, defensa y aliento de fuego definitivo.", 200, 0, 18, 0.40f, true)
    )),
    DWARF("enano", "Enano", "Resistencia, minería y maestría de forja", List.of(
            s("cuerpo_resistente", "Cuerpo resistente", "Reduce el daño recibido con resistencia temporal.", 26, 24, 0, 0, false),
            s("golpe_forge", "Golpe de forja", "Descarga un golpe potente sobre el enemigo cercano.", 18, 0, 8, 0.24f, false),
            s("sentido_minero", "Sentido minero", "Mejora la prisa minera y la suerte temporalmente.", 38, 40, 0, 0, false),
            s("armadura_reforzada", "Armadura reforzada", "Aumenta la resistencia durante más tiempo.", 50, 30, 0, 0, false),
            s("maestro_artesano", "Maestro artesano", "Mejora la prisa y la suerte de minería.", 70, 50, 0, 0, false),
            s("forja_ancestral", "Forja ancestral", "Refuerza al enano y golpea a los enemigos cercanos.", 180, 0, 16, 0.34f, true)
    )),
    SPIRIT("espiritu", "Espíritu", "Energía etérea y barreras", List.of(
            s("cuerpo_etero", "Cuerpo etéreo", "Vuelve al usuario invisible y ralentiza su caída.", 30, 14, 0, 0, false),
            s("proyectil_espiritual", "Proyectil espiritual", "Dispara energía concentrada al enemigo próximo.", 12, 0, 6, 0.20f, false),
            s("afinidad_espiritual", "Afinidad espiritual", "Aumenta la velocidad y la resistencia temporalmente.", 38, 25, 0, 0, false),
            s("barrera_energia", "Barrera de energía", "Concede resistencia y absorción al usuario.", 50, 28, 0, 0, false),
            s("conexion_espiritual", "Conexión espiritual", "Restaura salud y regeneración a aliados cercanos.", 72, 0, 9, 0.18f, false),
            s("espiritu_primordial", "Espíritu primordial", "Libera energía en área y potencia al usuario.", 190, 0, 17, 0.36f, true)
    )),
    VAMPIRE("vampiro", "Vampiro", "Velocidad nocturna y regeneración", List.of(
            s("sentidos_nocturnos", "Sentidos nocturnos", "Permite ver en la oscuridad y mejora el olfato de caza.", 24, 60, 0, 0, false),
            s("velocidad_vampirica", "Velocidad vampírica", "Aumenta notablemente la velocidad temporalmente.", 24, 22, 0, 0, false),
            s("regeneracion_vampirica", "Regeneración", "Restaura salud y concede regeneración temporal.", 42, 24, 0, 0, false),
            s("lanzas_carmesi", "Lanzas carmesíes", "Daña al enemigo próximo con energía carmesí.", 35, 0, 10, 0.28f, false),
            s("forma_murcielago", "Forma de murciélago", "Concede invisibilidad, velocidad y caída lenta.", 75, 12, 0, 0, false),
            s("senor_noche", "Señor de la noche", "Potencia al vampiro con velocidad, fuerza y regeneración.", 200, 40, 0, 0, true)
    )),
    MERFOLK("sirenido", "Sirenido", "Control de corrientes y protección marina", List.of(
            s("adaptacion_acuatica", "Adaptación acuática", "Otorga respiración acuática y visión submarina.", 25, 90, 0, 0, false),
            s("chorro_agua", "Chorro de agua", "Golpea al enemigo cercano con presión de agua.", 14, 0, 6, 0.18f, false),
            s("corriente_marina", "Corriente marina", "Empuja a los enemigos que rodean al sirenido.", 28, 0, 4, 0.10f, false),
            s("prision_agua", "Prisión de agua", "Ralentiza y debilita a los enemigos cercanos.", 42, 0, 6, 0.15f, false),
            s("marea_protectora", "Marea protectora", "Concede resistencia y respiración acuática temporal.", 56, 30, 0, 0, false),
            s("senor_mareas", "Señor de las mareas", "Desata una marea que daña enemigos y cura aliados.", 190, 0, 16, 0.34f, true)
    ));

    private final String id;
    private final String title;
    private final String subtitle;
    private final List<SkillDefinition> skills;

    SkillTree(String id, String title, String subtitle, List<SkillDefinition> skills) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.skills = List.copyOf(skills);
    }

    public String id() {
        return id;
    }

    public String title() {
        return title;
    }

    public String subtitle() {
        return subtitle;
    }

    public List<SkillDefinition> skills() {
        return skills;
    }

    public boolean contains(String skillId) {
        return skills.stream().anyMatch(skill -> skill.id().equals(skillId));
    }

    public static SkillTree fromId(String id) {
        if (id == null) {
            return null;
        }
        for (SkillTree tree : values()) {
            if (tree.id.equalsIgnoreCase(id)) {
                return tree;
            }
        }
        return null;
    }

    private static SkillDefinition s(String id, String name, String description, int cooldownSeconds,
                                     int durationSeconds, float basePower, float perLevel, boolean ultimate) {
        return new SkillDefinition(id, name, description, cooldownSeconds * 20,
                durationSeconds * 20, basePower, perLevel, ultimate);
    }
}
