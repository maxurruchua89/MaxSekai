package com.maxsekai.data;

import com.maxsekai.skill.SkillDefinition;
import com.maxsekai.skill.SkillTree;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

import java.util.HashMap;
import java.util.Map;

public final class PlayerRpgData implements IPlayerRpgData {
    public static final Capability<IPlayerRpgData> CAPABILITY =
            CapabilityManager.get(new CapabilityToken<>() {});
    private static final int MAX_SKILL_LEVEL = 99;
    private static final int MAX_SKILL_POINTS = 1_000_000;

    private String treeId = "";
    private int level = 1;
    private int xp;
    private int skillPoints;
    private int selectedSlot;
    private final Map<String, Integer> skillLevels = new HashMap<>();
    private final Map<String, String> equipment = new HashMap<>();
    private final Map<String, Long> cooldowns = new HashMap<>();
    private final int[] missionProgress = new int[3];

    @Override
    public String getTreeId() {
        return treeId;
    }

    @Override
    public void assignTree(String newTreeId) {
        SkillTree tree = SkillTree.fromId(newTreeId);
        if (tree == null) {
            throw new IllegalArgumentException("Árbol RPG desconocido: " + newTreeId);
        }
        treeId = tree.id();
        skillLevels.clear();
        equipment.clear();
        cooldowns.clear();
        selectedSlot = 0;
    }

    @Override
    public int getLevel() {
        return level;
    }

    @Override
    public int getXp() {
        return xp;
    }

    @Override
    public int getXpForNextLevel() {
        return Math.min(25_000, 100 + (level - 1) * 25);
    }

    @Override
    public int getSkillPoints() {
        return skillPoints;
    }

    @Override
    public int getSkillLevel(String skillId) {
        return skillLevels.getOrDefault(skillId, 0);
    }

    @Override
    public boolean upgradeSkill(String skillId) {
        SkillTree tree = SkillTree.fromId(treeId);
        SkillDefinition definition = SkillDefinition.find(skillId);
        if (tree == null || definition == null || !tree.contains(skillId) || skillPoints <= 0) {
            return false;
        }
        int current = getSkillLevel(skillId);
        if (current >= MAX_SKILL_LEVEL) {
            return false;
        }
        skillLevels.put(skillId, current + 1);
        skillPoints--;
        return true;
    }

    @Override
    public boolean setEquipment(int slot, String skillId) {
        if (slot < 0 || slot >= 4) {
            return false;
        }
        if (skillId == null || skillId.isBlank()) {
            equipment.remove(Integer.toString(slot));
            return true;
        }
        SkillTree tree = SkillTree.fromId(treeId);
        if (tree == null || !tree.contains(skillId) || getSkillLevel(skillId) <= 0) {
            return false;
        }
        equipment.put(Integer.toString(slot), skillId);
        return true;
    }

    @Override
    public String getEquipment(int slot) {
        return equipment.getOrDefault(Integer.toString(slot), "");
    }

    @Override
    public int getSelectedSlot() {
        return selectedSlot;
    }

    @Override
    public void setSelectedSlot(int slot) {
        if (slot >= 0 && slot < 4) {
            selectedSlot = slot;
        }
    }

    @Override
    public long getCooldownUntil(String skillId) {
        return cooldowns.getOrDefault(skillId, 0L);
    }

    @Override
    public void setCooldownUntil(String skillId, long gameTime) {
        cooldowns.put(skillId, gameTime);
    }

    @Override
    public void addXp(int amount) {
        if (amount <= 0) {
            return;
        }
        xp = Math.min(Integer.MAX_VALUE - amount, xp) + amount;
        while (xp >= getXpForNextLevel() && level < 10_000) {
            xp -= getXpForNextLevel();
            level++;
            skillPoints = Math.min(MAX_SKILL_POINTS, skillPoints + 1);
        }
    }

    @Override
    public void addSkillPoints(int amount) {
        if (amount > 0) {
            skillPoints = Math.min(MAX_SKILL_POINTS, skillPoints + amount);
        }
    }

    @Override
    public void reset() {
        treeId = "";
        level = 1;
        xp = 0;
        skillPoints = 0;
        selectedSlot = 0;
        skillLevels.clear();
        equipment.clear();
        cooldowns.clear();
        for (int i = 0; i < missionProgress.length; i++) {
            missionProgress[i] = 0;
        }
    }

    @Override
    public int getMissionProgress(int mission) {
        return mission >= 0 && mission < missionProgress.length ? missionProgress[mission] : 0;
    }

    @Override
    public void addMissionProgress(int mission, int amount) {
        if (mission >= 0 && mission < missionProgress.length && amount > 0) {
            missionProgress[mission] = Math.min(100_000, missionProgress[mission] + amount);
        }
    }

    @Override
    public boolean claimMission(int mission, int requirement) {
        if (mission < 0 || mission >= missionProgress.length || requirement <= 0 ||
                missionProgress[mission] < requirement) {
            return false;
        }
        missionProgress[mission] -= requirement;
        return true;
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString("tree", treeId);
        tag.putInt("level", level);
        tag.putInt("xp", xp);
        tag.putInt("skillPoints", skillPoints);
        tag.putInt("selectedSlot", selectedSlot);

        CompoundTag levelsTag = new CompoundTag();
        skillLevels.forEach(levelsTag::putInt);
        tag.put("skillLevels", levelsTag);

        CompoundTag equipmentTag = new CompoundTag();
        equipment.forEach(equipmentTag::putString);
        tag.put("equipment", equipmentTag);

        CompoundTag cooldownTag = new CompoundTag();
        cooldowns.forEach(cooldownTag::putLong);
        tag.put("cooldowns", cooldownTag);

        for (int i = 0; i < missionProgress.length; i++) {
            tag.putInt("mission_" + i, missionProgress[i]);
        }
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        String savedTree = tag.getString("tree");
        treeId = SkillTree.fromId(savedTree) == null ? "" : savedTree;
        level = Math.max(1, tag.getInt("level"));
        xp = Math.max(0, tag.getInt("xp"));
        skillPoints = Math.max(0, Math.min(MAX_SKILL_POINTS, tag.getInt("skillPoints")));
        selectedSlot = Math.max(0, Math.min(3, tag.getInt("selectedSlot")));

        skillLevels.clear();
        CompoundTag levelsTag = tag.getCompound("skillLevels");
        for (String key : levelsTag.getAllKeys()) {
            if (SkillDefinition.find(key) != null) {
                skillLevels.put(key, Math.max(0, Math.min(MAX_SKILL_LEVEL, levelsTag.getInt(key))));
            }
        }

        equipment.clear();
        CompoundTag equipmentTag = tag.getCompound("equipment");
        SkillTree tree = SkillTree.fromId(treeId);
        for (int slot = 0; slot < 4; slot++) {
            String key = equipmentTag.getString(Integer.toString(slot));
            if (tree != null && tree.contains(key) && getSkillLevel(key) > 0) {
                equipment.put(Integer.toString(slot), key);
            }
        }

        cooldowns.clear();
        CompoundTag cooldownTag = tag.getCompound("cooldowns");
        for (String key : cooldownTag.getAllKeys()) {
            if (SkillDefinition.find(key) != null) {
                cooldowns.put(key, Math.max(0L, cooldownTag.getLong(key)));
            }
        }
        for (int i = 0; i < missionProgress.length; i++) {
            missionProgress[i] = Math.max(0, Math.min(100_000, tag.getInt("mission_" + i)));
        }
    }
}
