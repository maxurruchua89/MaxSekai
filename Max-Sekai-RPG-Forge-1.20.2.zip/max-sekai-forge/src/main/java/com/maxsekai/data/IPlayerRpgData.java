package com.maxsekai.data;

import net.minecraft.nbt.CompoundTag;

public interface IPlayerRpgData {
    String getTreeId();
    void assignTree(String treeId);
    int getLevel();
    int getXp();
    int getXpForNextLevel();
    int getSkillPoints();
    int getSkillLevel(String skillId);
    boolean upgradeSkill(String skillId);
    boolean setEquipment(int slot, String skillId);
    String getEquipment(int slot);
    int getSelectedSlot();
    void setSelectedSlot(int slot);
    long getCooldownUntil(String skillId);
    void setCooldownUntil(String skillId, long gameTime);
    void addXp(int amount);
    void addSkillPoints(int amount);
    void reset();
    int getMissionProgress(int mission);
    void addMissionProgress(int mission, int amount);
    boolean claimMission(int mission, int requirement);
    CompoundTag serializeNBT();
    void deserializeNBT(CompoundTag tag);
}
