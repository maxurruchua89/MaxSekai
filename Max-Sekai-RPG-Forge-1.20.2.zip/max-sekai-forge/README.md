# Max Sekai RPG Mod

Mod RPG de fantasía para **Minecraft Java 1.20.2**, **Minecraft Forge 48.1.0** y **Java 17**.

## Compilar el JAR

Requisitos: JDK 17 y conexión a Internet para que Gradle descargue ForgeGradle y sus dependencias.

### Linux / macOS

```bash
./gradlew build
```

### Windows

```bat
gradlew.bat build
```

El JAR listo para instalar queda en `build/libs/maxsekai-1.0.0.jar`. Para probarlo dentro del entorno de desarrollo:

```bash
./gradlew runClient
```

Instala el JAR en la carpeta `mods` de un cliente o servidor con Minecraft 1.20.2 y Forge 48.1.0.

## Uso

- **K** abre/cierra el menú RPG.
- **R** activa la habilidad equipada en el espacio seleccionado.
- En **Habilidades**, mejora poderes con puntos. Cada poder tiene niveles 0–99.
- En **Equipamiento**, selecciona un espacio y asígnale una habilidad aprendida.
- En **Misiones**, reclama las recompensas al completar objetivos.

El administrador puede asignar manualmente un árbol, otorgar puntos/experiencia, consultar nivel y reiniciar progreso:

```text
/maxsekai asignar <jugador> <don>
/maxsekai puntos <jugador> <cantidad>
/maxsekai xp <jugador> <cantidad>
/maxsekai nivel <jugador>
/maxsekai reset <jugador>
```

Valores aceptados para `<don>`: `invocador`, `mago_elemental`, `sanador`, `espadachin_veloz`, `elfo`, `bestia`, `draconido`, `enano`, `espiritu`, `vampiro`, `sirenido`.

Los comandos requieren permiso de operador de nivel 2 o superior. La asignación es administrativa; cambiar el árbol reinicia las mejoras y espacios de habilidad de ese jugador. El nivel general y la experiencia se conservan.

## Progresión y seguridad

- El progreso, puntos, árbol asignado, niveles de habilidad, equipo, misiones y enfriamientos se guardan en los datos del jugador y se conservan al salir, morir o reiniciar el servidor.
- Las criaturas hostiles otorgan experiencia y actualizan misiones.
- Mejoras, equipamiento, misiones y activaciones se validan en el servidor; el cliente no puede forzar un árbol ajeno, saltarse niveles ni ignorar enfriamientos.
- Sanador no resucita entidades ni jugadores muertos.
- Las explosiones de habilidades no dañan bloques.

## Estructura

`src/main/java` contiene el mod, los datos persistentes, la red, los comandos y los efectos de las 66 habilidades. `src/main/resources` contiene metadatos, idioma y recursos.

## Licencia

MIT. Minecraft y Forge son marcas de sus respectivos propietarios.
