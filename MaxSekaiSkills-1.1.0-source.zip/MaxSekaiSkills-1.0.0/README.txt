MAX SEKAI SKILLS - prototipo RPG 1.1.0
Minecraft 1.20.2 | Forge 48.1.0 | Java 17

CONTROLES
K = abrir/cerrar el menu de habilidades.
R = activar el poder equipado.

COMANDOS
/maxsekai ayuda
/maxsekai estado
/maxsekai mejorar <1-6>
/maxsekai equipar <1-6>
/maxsekai usar
/maxsekai asignar <jugador> <don>       (OP)
/maxsekai puntos <jugador> <cantidad>  (OP)
/maxsekai exp <jugador> <niveles>      (OP, establece niveles vanilla de experiencia)

DON / ARBOLES
invocador, mago, sanador, espadachin, elfo, bestia, draconido, enano, espiritu, vampiro, sirenido.
Cada árbol tiene seis habilidades. Cada habilidad se mejora hasta nivel 99 gastando un punto.

PRUEBA RAPIDA PARA ADMIN
/maxsekai asignar TU_NICK bestia
/maxsekai puntos TU_NICK 30
/maxsekai exp TU_NICK 20
/maxsekai equipar 1
Pulsa K para abrir el menu y R para activar el poder equipado.

COMPILAR
Requiere JDK 17 y Gradle 8.8 (ForgeGradle 6 no funciona con Gradle 9+).
En la carpeta del proyecto: gradle build
El JAR queda en build/libs/.

NOTAS HONESTAS DEL PROTOTIPO
- Esta version incorpora controles K/R, pantalla inicial, seis niveles de habilidad por arbol (1-99), puntos, equipamiento y una primera habilidad activa en combate.
- La pantalla inicial muestra actualmente el arbol Bestia como interfaz de prueba; la sincronizacion visual de todos los arboles y sus niveles se debe completar en una siguiente iteracion.
- La experiencia del personaje usa los niveles vanilla de Minecraft; /maxsekai exp establece esos niveles.
- Las habilidades activas de esta primera iteracion son efectos de prueba, no animaciones/modelos personalizados. Los ataques varian segun don, pero necesitan mas balance y efectos propios.
- No se incluye un JAR precompilado en este ZIP. Es el proyecto fuente para compilar.
