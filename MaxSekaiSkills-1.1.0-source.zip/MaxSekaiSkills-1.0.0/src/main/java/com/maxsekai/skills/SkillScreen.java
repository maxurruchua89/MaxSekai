package com.maxsekai.skills;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import java.util.List;

public class SkillScreen extends Screen {
 private static final List<String> BEAST=List.of("Instinto salvaje","Garras bestiales","Fuerza animal","Transformación parcial","Transformación completa","Bestia ancestral");
 public SkillScreen(){super(Component.literal("MAX SEKAI"));}
 @Override protected void init(){int left=width/2-150,top=height/2-105;addRenderableWidget(Button.builder(Component.literal("Mejorar 1"),b->upgrade(1)).bounds(left+170,top+36,105,20).build());for(int i=2;i<=6;i++){final int n=i;addRenderableWidget(Button.builder(Component.literal("Mejorar "+i),b->upgrade(n)).bounds(left+170,top+36+(i-1)*27,105,20).build());addRenderableWidget(Button.builder(Component.literal("Equipar "+i),b->command("maxsekai equipar "+n)).bounds(left+65,top+36+(i-1)*27,95,20).build());}addRenderableableEquipOne(left,top);addRenderableWidget(Button.builder(Component.literal("Cerrar"),b->onClose()).bounds(left+90,top+205,110,20).build());}
 private void addRenderableableEquipOne(int x,int y){addRenderableWidget(Button.builder(Component.literal("Equipar 1"),b->command("maxsekai equipar 1")).bounds(x+65,y+36,95,20).build());}
 private void upgrade(int n){command("maxsekai mejorar "+n);}
 private void command(String s){if(minecraft!=null&&minecraft.player!=null)minecraft.player.connection.sendCommand(s);}
 @Override public void render(GuiGraphics g,int mx,int my,float partial){renderBackground(g);int x=width/2-150,y=height/2-105;g.fill(x-12,y-12,x+292,y+238,0xEE100B20);g.fill(x-10,y-10,x+290,y+236,0xFF7138D8);g.fill(x-7,y-7,x+287,y+233,0xF8141024);g.drawCenteredString(font,"✦ MAX SEKAI ✦",width/2,y+2,0xFFD7A6FF);String race="Sin raza/don";if(minecraft!=null&&minecraft.player!=null)race="Nivel de personaje: "+minecraft.player.experienceLevel;g.drawCenteredString(font,race,width/2,y+20,0xFFFFFFFF);List<String> names=BEAST;for(int i=0;i<6;i++){int yy=y+40+i*27;g.drawString(font,(i+1)+". "+names.get(i)+"  ·  hasta nivel 99",x+5,yy+6,0xFFE9DFFF,false);}g.drawCenteredString(font,"K: menú   |   R: poder equipado   |   Mejorar consume 1 punto",width/2,y+190,0xFFBDA6D9);super.render(g,mx,my,partial);}
 @Override public boolean isPauseScreen(){return false;}
}
