package com.maxsekai.skills;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.List;
import java.util.Map;

@Mod(MaxSekaiSkills.MODID)
public class MaxSekaiSkills {
 public static final String MODID="maxsekai_skills"; private static final String ROOT="MaxSekaiSkills";
 public static final Map<String,List<String>> TREES=Map.ofEntries(
 Map.entry("invocador",List.of("Llamado menor","Lobo espiritual","Guardianes gemelos","Bestia arcana","Ejército espiritual","Rey de las invocaciones")),
 Map.entry("mago",List.of("Chispa elemental","Afinidad elemental","Oleada elemental","Armadura elemental","Tormenta elemental","Cataclismo elemental")),
 Map.entry("sanador",List.of("Toque curativo","Luz restauradora","Barrera sagrada","Purificación","Zona de sanación","Milagro de vida")),
 Map.entry("espadachin",List.of("Corte veloz","Paso relámpago","Doble filo","Danza de espadas","Instinto del espadachín","Corte del vacío")),
 Map.entry("elfo",List.of("Visión élfica","Raíces atrapadoras","Bendición natural","Espinas del bosque","Espíritu del bosque","Guardián ancestral")),
 Map.entry("bestia",List.of("Instinto salvaje","Garras bestiales","Fuerza animal","Transformación parcial","Transformación completa","Bestia ancestral")),
 Map.entry("draconido",List.of("Escamas resistentes","Llama dracónica","Resistencia al calor","Aliento de dragón","Armadura dracónica","Despertar del dragón")),
 Map.entry("enano",List.of("Cuerpo resistente","Golpe de forja","Sentido minero","Armadura reforzada","Maestro artesano","Forja ancestral")),
 Map.entry("espiritu",List.of("Cuerpo etéreo","Proyectil espiritual","Afinidad espiritual","Barrera de energía","Conexión espiritual","Espíritu primordial")),
 Map.entry("vampiro",List.of("Sentidos nocturnos","Velocidad vampírica","Regeneración","Lanzas carmesí","Forma de murciélago","Señor de la noche")),
 Map.entry("sirenido",List.of("Adaptación acuática","Chorro de agua","Corriente marina","Prisión acuática","Marea protectora","Señor de las mareas")));
 public MaxSekaiSkills(){MinecraftForge.EVENT_BUS.register(this); }
 @SubscribeEvent public void commands(RegisterCommandsEvent e){e.getDispatcher().register(Commands.literal("maxsekai")
 .then(Commands.literal("ayuda").executes(c->{c.getSource().sendSuccess(()->Component.literal("K: menú | R: poder equipado | /maxsekai estado | /maxsekai mejorar <1-6>"),false);return 1;}))
 .then(Commands.literal("asignar").requires(s->s.hasPermission(2)).then(Commands.argument("jugador",EntityArgument.player()).then(Commands.argument("don",StringArgumentType.word()).suggests((c,b)->{TREES.keySet().forEach(b::suggest);return b.buildFuture();}).executes(c->{ServerPlayer p=EntityArgument.getPlayer(c,"jugador");String d=StringArgumentType.getString(c,"don").toLowerCase();if(!TREES.containsKey(d)){c.getSource().sendFailure(Component.literal("Don desconocido."));return 0;}var t=p.getPersistentData().getCompound(ROOT);t.putString("don",d);for(int i=0;i<6;i++)t.putInt("skill"+i,1);t.putInt("points",0);t.putInt("equipped",0);p.getPersistentData().put(ROOT,t);p.sendSystemMessage(Component.literal("Tu don es "+d+". ¡Abrí el menú con K!"));return 1;}))))
 .then(Commands.literal("puntos").requires(s->s.hasPermission(2)).then(Commands.argument("jugador",EntityArgument.player()).then(Commands.argument("cantidad",IntegerArgumentType.integer(1,10000)).executes(c->{var p=EntityArgument.getPlayer(c,"jugador");var t=data(p);t.putInt("points",t.getInt("points")+IntegerArgumentType.getInteger(c,"cantidad"));save(p,t);return 1;}))))
 .then(Commands.literal("exp").requires(s->s.hasPermission(2)).then(Commands.argument("jugador",EntityArgument.player()).then(Commands.argument("niveles",IntegerArgumentType.integer(0,999)).executes(c->{var p=EntityArgument.getPlayer(c,"jugador");p.setExperienceLevels(IntegerArgumentType.getInteger(c,"niveles"));p.sendSystemMessage(Component.literal("Tu nivel de experiencia fue actualizado."));return 1;}))))
 .then(Commands.literal("mejorar").then(Commands.argument("habilidad",IntegerArgumentType.integer(1,6)).executes(c->upgrade(c.getSource().getPlayerOrException(),IntegerArgumentType.getInteger(c,"habilidad")-1))))
 .then(Commands.literal("equipar").then(Commands.argument("habilidad",IntegerArgumentType.integer(1,6)).executes(c->{var p=c.getSource().getPlayerOrException();var t=data(p);t.putInt("equipped",IntegerArgumentType.getInteger(c,"habilidad")-1);save(p,t);p.sendSystemMessage(Component.literal("Habilidad equipada."));return 1;})))
 .then(Commands.literal("usar").executes(c->use(c.getSource().getPlayerOrException())))
 .then(Commands.literal("estado").executes(c->{var p=c.getSource().getPlayerOrException();var t=data(p);String d=t.getString("don");var names=TREES.get(d);p.sendSystemMessage(Component.literal("Don: "+(d.isEmpty()?"sin asignar":d)+" | Nivel: "+p.experienceLevel+" | Puntos: "+t.getInt("points")));if(names!=null)for(int i=0;i<6;i++)p.sendSystemMessage(Component.literal((i+1)+". "+names.get(i)+" - nivel "+t.getInt("skill"+i)+"/99"));return 1;})) );}
 private static net.minecraft.nbt.CompoundTag data(ServerPlayer p){return p.getPersistentData().getCompound(ROOT).copy();} private static void save(ServerPlayer p,net.minecraft.nbt.CompoundTag t){p.getPersistentData().put(ROOT,t);}
 private static int upgrade(ServerPlayer p,int i){var t=data(p);String d=t.getString("don");if(!TREES.containsKey(d)){p.sendSystemMessage(Component.literal("Todavía no tienes un don asignado."));return 0;}int n=t.getInt("skill"+i);if(n>=99){p.sendSystemMessage(Component.literal("Esta habilidad ya llegó al nivel 99."));return 0;}if(t.getInt("points")<1){p.sendSystemMessage(Component.literal("No tienes puntos de habilidad."));return 0;}t.putInt("skill"+i,n+1);t.putInt("points",t.getInt("points")-1);save(p,t);p.sendSystemMessage(Component.literal(TREES.get(d).get(i)+" mejorada a nivel "+(n+1)+"/99."));return 1;}
 private static int use(ServerPlayer p){var t=data(p);String d=t.getString("don");if(!TREES.containsKey(d)){p.sendSystemMessage(Component.literal("No tienes un don asignado."));return 0;}int i=t.getInt("equipped"),lvl=t.getInt("skill"+i);if(lvl<1){p.sendSystemMessage(Component.literal("Habilidad no desbloqueada."));return 0;}p.getCooldowns().addCooldown(net.minecraft.world.item.Items.NETHER_STAR,40);if(d.equals("bestia")){p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,Math.min(4,lvl/20)));p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,Math.min(3,lvl/25)));for(LivingEntity target:p.level().getEntitiesOfClass(LivingEntity.class,new AABB(p.blockPosition()).inflate(3),x->x!=p&&!x.isAlliedTo(p))){target.hurt(p.damageSources().playerAttack(p),3+lvl*0.5f);}}else if(d.equals("sanador")){p.heal(2+lvl*0.2f);p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,Math.min(2,lvl/30)));}else{p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,Math.min(3,lvl/25)));for(LivingEntity target:p.level().getEntitiesOfClass(LivingEntity.class,new AABB(p.blockPosition()).inflate(3),x->x!=p&&!x.isAlliedTo(p)))target.hurt(p.damageSources().playerAttack(p),2+lvl*0.4f);}p.sendSystemMessage(Component.literal("¡Usaste "+TREES.get(d).get(i)+"!"));return 1;}
}
