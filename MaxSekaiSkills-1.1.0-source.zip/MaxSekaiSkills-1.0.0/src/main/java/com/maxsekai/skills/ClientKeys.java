package com.maxsekai.skills;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=MaxSekaiSkills.MODID, value=Dist.CLIENT, bus=Mod.EventBusSubscriber.Bus.MOD)
public class ClientKeys {
 public static KeyMapping MENU, POWER;
 @SubscribeEvent public static void register(RegisterKeyMappingsEvent e){MENU=new KeyMapping("key.maxsekai.menu",KeyConflictContext.IN_GAME,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_K,"key.categories.maxsekai");POWER=new KeyMapping("key.maxsekai.power",KeyConflictContext.IN_GAME,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,"key.categories.maxsekai");e.register(MENU);e.register(POWER);}
 @Mod.EventBusSubscriber(modid=MaxSekaiSkills.MODID,value=Dist.CLIENT)
 public static class Ticks { @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){if(e.phase!=TickEvent.Phase.END)return;Minecraft mc=Minecraft.getInstance();if(mc.player==null)return;if(MENU!=null&&MENU.consumeClick())mc.setScreen(new SkillScreen());if(POWER!=null&&POWER.consumeClick())mc.player.connection.sendCommand("maxsekai usar");} }
}
